package com.example.jsouptest;
import android.os.AsyncTask;

import java.io.IOException;




import org.jsoup.Connection;
import org.jsoup.Jsoup;
import org.jsoup.UnsupportedMimeTypeException;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;

import java.io.IOException;

public class SNHULogOn extends AsyncTask<String, String, String> {

    SNHULogOn() {

        /*try
        {
            System.out.println("In SNHULogOn");
            Document dc = Jsoup.connect("https://get.cbord.com/snhu/full/login.php").timeout(6000).get();
            System.out.println(dc.title());
        }
        catch (Exception e)
        {
            System.out.println("In SNHULogOn catch");
            System.out.println(e);
        }*/
    }

    public String doInBackground(String... urls) {
        try {
            System.out.println("In SNHULogOn");
            Document dc = Jsoup.connect("https://get.cbord.com/snhu/full/login.php").timeout(6000).get();
            System.out.println(dc.title());
            System.out.println("Exit SNHULogOn");

            return "Yes";
        } catch (Exception e) {
            System.out.println("In SNHULogOn catch");
            System.out.println(e);
            return "No";
        } finally {
            return "Maybe";
        }
    }
}
